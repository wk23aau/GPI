import { ResumeData } from './types';

export const INITIAL_RESUME: ResumeData = {
  personalInfo: {
    name: "WASEEM RAZA KHAN",
    title: "Administrative & Data Assistant",
    address: "17 Brockley Gove, Lewisham | London, SE4 1QX",
    phone: "+447404132345",
    email: "waseemrazakhan0@gmail.com"
  },
  summary: "A highly organized and tech-savvy professional with an MSc in Data Science and practical experience in operations and inventory management. I possess advanced proficiency in Microsoft Office and Google Workspace, with a strong ability to manage data, handle correspondence, and maintain accurate digital records. I am disciplined, detail-oriented, and fully equipped to work remotely with minimal supervision.",
  skills: [
    {
      category: "Administrative",
      items: ["Data Entry", "File Management", "Scheduling", "Invoicing", "Email Management"]
    },
    {
      category: "Software",
      items: ["Microsoft Office (Advanced Excel, Word, PowerPoint)", "Google Workspace (Docs, Sheets, Drive)", "Outlook"]
    },
    {
      category: "Financial",
      items: ["Invoice Checking", "Inventory Tracking", "Basic Bookkeeping concepts"]
    },
    {
      category: "Soft Skills",
      items: ["Professional Phone Etiquette", "Time Management", "Independent Problem Solving"]
    },
    {
      category: "Languages",
      items: ["English (Fluent – Written & Spoken)", "Urdu/Hindi"]
    }
  ],
  experience: [
    {
      company: "Abarbistro",
      location: "Portsmouth, UK",
      role: "Operations Assistant",
      dates: "Jan 2024 – Present | Part-Time",
      description: "Managed back-of-house organization and stock control for a busy bistro.",
      bullets: [
        "Inventory Administration: Checked incoming deliveries against invoices to ensure accuracy, reporting any discrepancies to management immediately.",
        "Organization: Maintained organized storage systems (Dry Stores/Cold Rooms) to ensure efficient retrieval of stock.",
        "Compliance: Adhered to health and safety documentation and waste management protocols."
      ]
    },
    {
      company: "Al Yamama Company",
      location: "Saudi Arabia",
      role: "Logistics & Data Assistant",
      dates: "Jan 2023 – Jan 2024 | Full-Time",
      description: "Supported the administrative side of a large-scale infrastructure project.",
      bullets: [
        "Data Entry & Tracking: Used digital scanners and manual checklists to input inventory levels into the company database, ensuring 100% data accuracy.",
        "Documentation: Managed shipping manifests and delivery notes, filing them correctly for audit purposes.",
        "Order Processing: Received and processed daily material requests, coordinating with the warehouse team to ensure timely dispatch.",
        "Communication: Liaised with site supervisors to confirm receipt of goods and resolve delivery queries.",
        "Fast-Paced Processing: Located and packed items rapidly to meet transport deadlines, ensuring no delays to the supply chain."
      ]
    },
    {
      company: "Imtiaz Store",
      location: "Lahore, Pakistan",
      role: "Retail Assistant",
      dates: "2019 - 2022 | Full-Time",
      description: "Front-line customer service role involving cash handling and stock monitoring.",
      bullets: [
        "Customer Service: Handled customer inquiries in person and over the phone, resolving issues professionally.",
        "Transaction Management: Operated the Point of Sale (POS) system accurately; handled cash balancing at the end of shifts.",
        "Stock Recording: Monitored shelf stock levels and expiration dates, updating inventory logs accordingly."
      ]
    }
  ],
  education: [
    {
      degree: "MSc Data Science & Analytics (Advanced Research)",
      institution: "University of Hertfordshire",
      location: "Hertfordshire, UK",
      dates: "January 2024 – December 2025",
      details: [
        "Relevant Skills: Advanced Data Analysis, Report Writing, Presentation (PowerPoint), Advanced Excel (Pivot Tables, VLOOKUP)."
      ]
    },
    {
      degree: "Bachelor of Science (Computer Science)",
      institution: "The Islamia University of Bahawalpur",
      location: "Bahawalpur, PK",
      dates: "October 2015 – July 2019",
      details: [
        "Relevant Skills: Typing speed (60+ WPM), Software troubleshooting, Database management."
      ]
    }
  ],
  technicalSetup: [
    "Reliable High-Speed Internet connection.",
    "Personal Laptop with full Microsoft Office Suite & Zoom/Teams capability.",
    "Quiet home-office environment suitable for handling professional calls."
  ],
  additionalInfo: [
    "Available 11th December 2025.",
    "Open to Full-time, Part-time, or Temp-to-Perm contracts."
  ]
};